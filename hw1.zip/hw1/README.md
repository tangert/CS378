## Running 

On a computer with python installed:
run "python apriori.py INPUT_FILE MIN_SUPPORT_COUNT OUTPUT_FILE"

ex: 
> python apriori.py DATASET.dat 1000 output1000.dat