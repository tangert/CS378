# Tyler Angert CS378 HW2

## Introduction

This project implements both the c4.5 algorithm to build a decision tree, as well as a Naive Bayes classifier both in Python.


## Running the program

On a computer with python installed: 

run "python [c45.py/bayes.py] TRAINING_FILE TESTING_FILE OUTPUT_FILE"


## Notes

I couldn't get files to read from either "mushroom.training" or "mushroom.test", but I could with "mushroom.training.txt" and "mushroom.test.txt"